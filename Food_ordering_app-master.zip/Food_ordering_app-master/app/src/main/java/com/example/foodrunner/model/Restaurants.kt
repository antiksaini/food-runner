package com.example.foodrunner.model

class Restaurants(
    val restaurantId: Int,
    val restaurantName: String,
    val restaurantRating: String,
    val restaurantPrice:String,
    val restaurantImageUrl:String
) {
}