package com.example.foodrunner.model

import android.widget.Button

class menu(
    val id: String,
    val itemName: String,
    val itemPrice: Int
) {
}